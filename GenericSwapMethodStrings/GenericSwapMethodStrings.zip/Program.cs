﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericSwapMethodStrings
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<string> values = new List<string>();
            int n = int.Parse(Console.ReadLine());
            for (int i=0; i< n; i++)
            {
                string input = Console.ReadLine();
                values.Add(input);
            }

            Box<string> box = new Box<string>(values);

            int[] arr = Console.ReadLine()
            .Split()
            .Select(int.Parse).ToArray();

            int firstElement = arr[0];
            int secondElement = arr[1];
            box.SwapElements(firstElement, secondElement);
            Console.WriteLine(box);
        }
    }
}
